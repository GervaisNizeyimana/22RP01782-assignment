
package AllClasses;



public class PrintName {

    
    public static void main(String[] args) {
        
        System.out.println("Nizeyimana Gervais - 22RP01782");
     
      
        
    }
    
    
    
}

